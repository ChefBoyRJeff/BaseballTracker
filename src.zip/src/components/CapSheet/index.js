// Main export file for CapSheet component
import CapSheet from './CapSheet';

export default CapSheet;